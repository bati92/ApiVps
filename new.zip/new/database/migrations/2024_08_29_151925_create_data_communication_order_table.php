<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('data_communication_orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('data_communication_id');
            $table->integer('user_id');
            $table->foreign('data_communication_id')->references('id')->on('data_communications')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->decimal('price', 8, 4);
            $table->string('mobile');
            $table->integer('count');
            $table->string('note')->nullable();
            
            $table->string('status')->nullable()->default('قيد المراجعة');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('data_orders');
    }
};
